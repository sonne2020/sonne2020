<?php











namespace Composer\Repository;






class RepositorySecurityException extends \Exception
{
}
