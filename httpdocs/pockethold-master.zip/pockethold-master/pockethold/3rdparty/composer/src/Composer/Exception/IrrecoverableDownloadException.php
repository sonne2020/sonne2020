<?php











namespace Composer\Exception;




class IrrecoverableDownloadException extends \RuntimeException
{
}
