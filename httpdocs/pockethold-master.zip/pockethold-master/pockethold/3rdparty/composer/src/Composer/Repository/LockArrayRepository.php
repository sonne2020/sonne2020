<?php











namespace Composer\Repository;








class LockArrayRepository extends ArrayRepository
{
public function getRepoName()
{
return 'lock repo';
}
}

