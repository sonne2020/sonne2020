<?php











namespace Composer\Installer;

class InstallerEvents
{








const PRE_OPERATIONS_EXEC = 'pre-operations-exec';
}
