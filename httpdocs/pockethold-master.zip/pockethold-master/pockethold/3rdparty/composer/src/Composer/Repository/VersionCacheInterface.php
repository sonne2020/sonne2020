<?php











namespace Composer\Repository;

interface VersionCacheInterface
{





public function getVersionPackage($version, $identifier);
}
