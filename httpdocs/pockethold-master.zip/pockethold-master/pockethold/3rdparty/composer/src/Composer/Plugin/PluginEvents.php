<?php











namespace Composer\Plugin;






class PluginEvents
{








const INIT = 'init';









const COMMAND = 'command';









const PRE_FILE_DOWNLOAD = 'pre-file-download';









const POST_FILE_DOWNLOAD = 'post-file-download';









const PRE_COMMAND_RUN = 'pre-command-run';










const PRE_POOL_CREATE = 'pre-pool-create';
}
