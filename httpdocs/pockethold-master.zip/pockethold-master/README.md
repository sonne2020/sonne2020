<img alt="Pockethold" src="https://i.imgur.com/k5tMKCG.png">


# Web-based flarum installer/downloader
* Goal: Provide a non shell alternative for installing Flarum.

Requirements.
1. cUrl or allow_url_fopen, proc_open)
2. PHP Memory limit at least 512M 
3. Rougly 3 - 5 minutes of your time. 

Usage:
Upload installer.php where you want Flarum to be installed. 
Visit the the default: `yoururl.com/installer.php` and follow the instructions. 

Pockethold will redirect you upon completion.
